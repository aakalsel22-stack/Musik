# DarkStream Player — Android

Aplikasi contoh pemutar audio streaming dengan UI dark, ExoPlayer/Media3, input URL stream, kontrol play/pause/next/stop, dan panel equalizer 31 slider.

## Penting tentang equalizer 31-band
Panel menampilkan 31 titik frekuensi dari 20 Hz sampai 20 kHz. Implementasi awal menggunakan Android `android.media.audiofx.Equalizer`, yang jumlah band perangkat kerasnya ditentukan oleh HP/ROM (sering hanya 5 atau 10 band). Karena itu beberapa slider dapat mengendalikan band perangkat yang sama. Ini **bukan 31 filter DSP independen**. Untuk 31-band independen di semua perangkat, perlu ditambahkan DSP 31 biquad khusus di jalur audio dan pengujian kompatibilitas perangkat.

## Persyaratan
- Android Studio (versi yang mendukung AGP 8.7.3)
- JDK 17
- Android SDK Platform 35
- Koneksi internet saat Gradle mengunduh dependensi

## Membuka dan membuat APK
1. Ekstrak ZIP.
2. Android Studio → **Open** → pilih folder `DarkStreamPlayer`.
3. Tunggu Gradle Sync selesai.
4. Sambungkan HP Android dengan USB debugging aktif, atau buat emulator.
5. Tekan **Run** untuk mencoba.
6. Untuk APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Menggunakan
1. Jalankan aplikasi.
2. Masukkan URL langsung ke file audio atau endpoint streaming yang kompatibel (misalnya MP3/AAC/HLS yang didukung Media3).
3. Tekan **Putar URL streaming**.
4. Buka **31 Band** untuk mengatur equalizer.

## Catatan
- Gunakan URL stream yang Anda miliki atau diizinkan untuk diputar. URL halaman web biasa bukan URL audio.
- Proyek ini adalah source project Android Studio, bukan file APK yang sudah dikompilasi. APK perlu dibangun dengan Android Studio/Gradle.
- Versi awal ini belum menyediakan katalog musik, akun layanan streaming komersial, pencarian radio otomatis, atau pemutaran background melalui foreground media service.
