package com.example.darkstream

import android.media.audiofx.Equalizer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.ln
import kotlin.math.roundToInt

private val Bg = Color(0xFF09090F)
private val Panel = Color(0xFF171722)
private val Accent = Color(0xFF9B7BFF)
private val TextMain = Color(0xFFF4F1FF)
private val TextMuted = Color(0xFFAAA5BC)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private var equalizer: Equalizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg, surface = Panel, primary = Accent,
                    onBackground = TextMain, onSurface = TextMain
                )
            ) {
                PlayerScreen(
                    player = player,
                    onAttachEqualizer = { attachEqualizer() },
                    onSetEq = { band, value -> setEqFrom31Band(band, value) }
                )
            }
        }
    }

    private fun attachEqualizer() {
        try {
            equalizer?.release()
            equalizer = Equalizer(0, player.audioSessionId).apply { enabled = true }
        } catch (_: Exception) { equalizer = null }
    }

    // Android's built-in EQ exposes a device-dependent number of bands.
    // The 31 UI controls are mapped to the nearest available hardware band.
    private fun setEqFrom31Band(index: Int, db: Float) {
        val eq = equalizer ?: return
        try {
            val count = eq.numberOfBands.toInt()
            if (count <= 0) return
            val targetHz = bandFrequency(index)
            var nearest: Short = 0
            var smallest = Float.MAX_VALUE
            for (i in 0 until count) {
                val hz = eq.getCenterFreq(i.toShort()).toFloat().coerceAtLeast(1f)
                val distance = kotlin.math.abs(ln(hz / targetHz))
                if (distance < smallest) {
                    smallest = distance
                    nearest = i.toShort()
                }
            }
            val range = eq.bandLevelRange
            val level = (db * 100f).roundToInt()
                .coerceIn(range[0].toInt(), range[1].toInt()).toShort()
            eq.setBandLevel(nearest, level)
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        equalizer?.release()
        player.release()
        super.onDestroy()
    }
}

private fun bandFrequency(index: Int): Float =
    (20.0 * Math.pow(1000.0, index.coerceIn(0, 30) / 30.0)).toFloat()

@Composable
private fun PlayerScreen(
    player: ExoPlayer,
    onAttachEqualizer: () -> Unit,
    onSetEq: (Int, Float) -> Unit
) {
    var streamUrl by remember { mutableStateOf("https://") }
    var title by remember { mutableStateOf("Belum ada stream") }
    var status by remember { mutableStateOf("Tempel URL audio streaming yang legal") }
    var playing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showEq by remember { mutableStateOf(false) }
    val playlist = remember { mutableStateListOf<String>() }
    val levels = remember { mutableStateListOf<Float>().apply { repeat(31) { add(0f) } } }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(playbackError: PlaybackException) {
                error = playbackError.message ?: "Stream tidak dapat diputar"
                status = "Gagal memutar stream"
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                title = mediaItem?.mediaMetadata?.title?.toString()
                    ?: mediaItem?.localConfiguration?.uri?.host ?: "Live stream"
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Text("DARKSTREAM", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Text("Music Player", color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text("Streaming • Hi-Fi controls", color = TextMuted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(176.dp).background(
                        brush = androidx.compose.ui.graphics.Brush.linearGradient(
                            listOf(Color(0xFF37245F), Color(0xFF151526), Color(0xFF442B69))
                        ), shape = RoundedCornerShape(28.dp)
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("♫", color = Color.White, fontSize = 86.sp)
                }
                Spacer(Modifier.height(18.dp))
                Text(title, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(status, color = TextMuted, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    IconButton(onClick = { player.seekToPreviousMediaItem() }) {
                        Icon(Icons.Default.SkipNext, "Sebelumnya", tint = TextMuted, modifier = Modifier.size(28.dp))
                    }
                    FilledIconButton(
                        onClick = {
                            if (playing) player.pause() else {
                                if (player.mediaItemCount > 0) player.play()
                                else error = "Tambahkan URL stream terlebih dahulu"
                            }
                        },
                        modifier = Modifier.size(64.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Accent)
                    ) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause",
                            tint = Color.White, modifier = Modifier.size(36.dp))
                    }
                    IconButton(onClick = { player.seekToNextMediaItem() }) {
                        Icon(Icons.Default.SkipNext, "Berikutnya", tint = TextMuted, modifier = Modifier.size(28.dp))
                    }
                    IconButton(onClick = { player.stop(); playing = false }) {
                        Icon(Icons.Default.Stop, "Stop", tint = TextMuted)
                    }
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Text("TAMBAH STREAM", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = streamUrl, onValueChange = { streamUrl = it; error = null },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("https://alamat-stream/audio.mp3") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF393546),
                focusedTextColor = TextMain, unfocusedTextColor = TextMain
            )
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                val url = streamUrl.trim()
                if (!url.startsWith("https://") && !url.startsWith("http://")) {
                    error = "Masukkan URL stream HTTP atau HTTPS yang valid"
                } else {
                    playlist.add(url)
                    player.setMediaItem(MediaItem.fromUri(url))
                    player.prepare()
                    player.play()
                    status = "Menghubungkan ke stream…"
                    error = null
                    onAttachEqualizer()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Accent)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("Putar URL streaming")
        }
        error?.let { Text(it, color = Color(0xFFFF8B8B), fontSize = 12.sp) }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("EQUALIZER", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { showEq = !showEq }) { Text(if (showEq) "Tutup" else "31 Band") }
        }
        if (showEq) {
            Text("Geser untuk mengatur gain tiap frekuensi (−12 sampai +12 dB).", color = TextMuted, fontSize = 11.sp)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                items((0..30).toList()) { i ->
                    val hz = bandFrequency(i).roundToInt()
                    val label = if (hz >= 1000) "${"%.1f".format(hz / 1000f)} kHz" else "$hz Hz"
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(label, color = TextMuted, modifier = Modifier.width(58.dp), fontSize = 11.sp)
                        Slider(
                            value = levels[i], onValueChange = {
                                levels[i] = it
                                onSetEq(i, it)
                            },
                            valueRange = -12f..12f,
                            modifier = Modifier.weight(1f)
                        )
                        Text("${levels[i].roundToInt()} dB", color = TextMain, modifier = Modifier.width(42.dp), fontSize = 10.sp)
                    }
                }
            }
        } else {
            Text("Playlist: ${playlist.size} URL tersimpan selama aplikasi terbuka", color = TextMuted, fontSize = 11.sp)
        }
    }
}
